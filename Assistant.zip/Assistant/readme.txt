common_command:
			python manage.py runserver
			python manage.py makemigrations