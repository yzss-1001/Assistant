"""
URL configuration for Assistant project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from vision import views

urlpatterns = [
    path("", views.login, name="login"),  # http://localhost:8000/
    path("user_register/", views.register, name="register"),  # http://localhost:8000/user_register/
    path("home/", views.home, name="home"),  # http://localhost:8000/home/
    path("textToImage/", views.texttoimage, name="textToImage"),  # http://localhost:8000/textToImage/
    path("language_model/", views.language_model, name="language_model"),  # http://localhost:8000/language_model/
    path("image_model/", views.image_model, name="image_model"),  # http://localhost:8000/image_model/
]
