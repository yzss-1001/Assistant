from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from .models import Userinfo  # .models, 前面的点代表寻找同级模块不可省略。
from .process_ai import ZhiPuAi
from .process_ai import textToImage
import base64
import json

# Create your views here.


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username)
        print(password)
        user_exists = Userinfo.objects.filter(username=username, password=password).exists()
        if user_exists:
            data = {
                "success": True,
                "message": "登录成功"
            }
            return JsonResponse(data)
        else:
            data = {
                "success": False,
                "message": "登录失败"
            }
            return JsonResponse(data)

    else:
        return render(request, "user_login.html")


def register(request):
    if request.method == 'POST':
        firstName = request.POST.get('firstName')
        lastName = request.POST.get('lastName')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        gender = request.POST.get('gender')
        if gender == 'male':
            gender = '男'
        else:
            gender = '女'
        print(firstName)
        print(lastName)
        print(email)
        print(phone)
        print(password)
        print(gender)
        #  这里向mysql添加用户数据
        userinfo = Userinfo.objects.create(username=lastName+firstName, password=password, email=email,
                                           phone=phone, gender=gender)
        # 验证返回实列是否与添加一致
        if userinfo:
            addSuccess = True
        else:
            addSuccess = False

        if addSuccess:
            data = {
                "success": True,
                "message": "注册成功",
                "redirect_url": "http://localhost:8000/",
                "username": userinfo.username
            }
            return JsonResponse(data)
        else:
            data = {
                "success": False,
                "message": "注册失败"
            }
            return JsonResponse(data)

    else:
        return render(request, "user_register.html")


def home(request):
    return render(request, "home.html")


def texttoimage(request):
    return render(request, "textToImage.html")


def language_model(request):
    if request.method == 'POST':
        message = request.POST.get('message')
        message_type = request.POST.get('message_type')
        print(f"用户输入：{message}")
        print(f"输入类型：{message_type}")
        ai_answer = ZhiPuAi.ai_answer(message)
        data = {
            "response": ai_answer
        }
        return JsonResponse(data)
    else:
        pass


def image_model(request):

    if request.method == 'POST':
        prompt = request.POST.get('prompt')
        # image_style = request.POST.get('image_style')
        print(f"用户输入(文生图提示词)：{prompt}")
        # print(f"图像风格：{image_style}")
        image_data = textToImage.produce_image(prompt)

        # 如果image_data是字节数据，转换为base64
        if isinstance(image_data, bytes):
            image_base64 = base64.b64encode(image_data).decode('utf-8')
        else:
            image_base64 = image_data  # 假设已经是base64字符串

        data = {
            "success": True,
            "image_data": image_base64,
            "message": "图像生成成功"
        }
        return JsonResponse(data)
    else:
        pass

