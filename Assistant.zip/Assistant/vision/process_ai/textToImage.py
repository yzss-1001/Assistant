from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.hunyuan.v20230901 import hunyuan_client, models
import json
import base64


def produce_image(message: str):
    # 认证信息
    cred = credential.Credential("AKIDQxRjp6A41FWcXItKbieQ0NH0Wr0zqY4M", "84nJbgbKqDictDTZS8iAVt7Pfp0444yn")

    # 客户端配置
    httpProfile = HttpProfile()
    httpProfile.endpoint = "hunyuan.tencentcloudapi.com"

    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile
    clientProfile.signMethod = "TC3-HMAC-SHA256"

    # 初始化客户端 - 使用广州地域
    client = hunyuan_client.HunyuanClient(cred, "ap-guangzhou", clientProfile)

    # 使用 TextToImageLiteRequest
    req = models.TextToImageLiteRequest()

    # 设置参数
    # req.Prompt = "一只可爱的猫咪，坐在窗边，阳光明媚，卡通风格"
    req.Prompt = message
    req.Resolution = "768:768"  # 设置分辨率
    req.LogoAdd = 0  # 不添加水印

    try:
        resp = client.TextToImageLite(req)
        print("请求成功！")

        # 打印响应信息
        print(f"请求ID: {resp.RequestId}")

        # 处理图片数据
        if hasattr(resp, 'ResultImage') and resp.ResultImage:
            try:
                # 尝试直接解码base64字符串
                if isinstance(resp.ResultImage, str):
                    image_data = base64.b64decode(resp.ResultImage)
                    # print(image_data)
                    return image_data
                    # with open("output/generated_image.png", "wb") as f:
                    #     f.write(image_data)
                    # print("图片已保存为 output/generated_image.png")
                else:
                    # # 如果已经是字节数据，直接保存
                    # with open("output/generated_image.png", "wb") as f:
                    #     f.write(resp.ResultImage)
                    print("图片已保存为 generated_image.png")
            except Exception as img_error:
                print(f"保存图片时出错: {img_error}")
                print(f"ResultImage 类型: {type(resp.ResultImage)}")

        # # 打印其他响应信息
        # print(f"响应: {resp.to_json_string()}")

    except Exception as e:
        print(f"调用API时出错: {e}")
