from zhipuai import ZhipuAI


def ai_answer(message: str) -> str:
    # 2. 初始化客户端
    client = ZhipuAI(api_key="a15ed2dc93624cbb8f933e0aee7e9a98.rkNooKiWDw9iO49w")

    # 3. 使用新的客户端和调用方法发起请求
    response = client.chat.completions.create(
        model="glm-4",  # 指定需要使用的模型名称，如 glm-4, glm-3-turbo
        messages=[
            {
                "role": "system",
                "content": """你是一个专业的办公助手，专注于帮助用户处理各类办公场景中的问题。请遵循以下要求：
                1. 回答要专业、简洁、实用
                2. 提供具体的操作步骤和解决方案
                3. 对于Office软件问题，给出详细的操作指引
                4. 对于文档处理，提供实用的技巧和建议
                5. 保持友好和耐心的态度"""
            },
            {"role": "user", "content": message}  # 注意消息格式
        ]
    )

    # 4. 打印回复
    # print(response.choices[0].message.content)
    return response.choices[0].message.content

